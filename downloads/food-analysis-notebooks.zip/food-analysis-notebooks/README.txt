食品分析實驗 Jupyter 筆記本（離線版）

1. 安裝 Anaconda（https://www.anaconda.com/download），或 JupyterLab Desktop。
2. 解壓縮本資料夾，開啟 Anaconda Navigator → JupyterLab，切到這個資料夾。
3. 打開 notebooks/ 裡的 .ipynb，選「Run → Run All Cells」。
   筆記本已內建模擬資料，不需網路；要換成班級數據，把 CSV 放進 data/ 並依筆記本說明改檔名。
4. 需要的套件：numpy、pandas、scipy、matplotlib、scikit-learn（Anaconda 都已內建）。
   其他 Python 環境可執行：pip install numpy pandas scipy matplotlib scikit-learn jupyterlab
